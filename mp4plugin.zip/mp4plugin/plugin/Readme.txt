﻿https://help.webex.com/en-us/WBX56022/Prompted-to-Enter-URL-Account-Name-and-Password-when-Converting-an-NBR-to-MP4-Format


If the plug-in is blocked:

1) Download the plugin.zip file  --->  https://github.com/spinalgr1990/WebexTools

2) Unzip the files and extract the complete 'plugin' folder 

3) Note: Create a 'plugin' folder if it does not already exist.


Re-try the .ARF to .MP4 conversion process.

-----------------------------------------------------------------------------------------------------------------------------------------




plugin location : 

x32 system : C:\Program Files\Webex\Webex\500

x64 system : C:\Program Files (x86)\Webex\Webex\500