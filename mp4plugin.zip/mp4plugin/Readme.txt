-----------------------------------------------------------------------------------------------------------------------------------------

MP4 Conversion Components

The MP4 components are not shipped with the NBR player.
They are licensed separately from the EULA and are deployed to the NBR installation after the end user accepts the license agreement.

The MP4 components are a plugin for Cisco WebEx NBR Player. Plugins are installed in a directory named Plugins.
This directory is located under the installation directory at .\Webex\500\Plugin. E.G. : C:\Program Files (x86)\Webex\Webex\500\Plugin

The MP4 Components files are as listed:

atgpcext.dll is The Download Module DLL
libfaac.dll is The FFmpeg AAC DLL


Documentation on how to manually install the files is here:
https://help.webex.com/en-us/WBX56022/Prompted-to-Enter-URL-Account-Name-and-Password-when-Converting-an-NBR-to-MP4-Format

----------------------------------------------------------------------------------------------------------------------------------------------
plugin location : 

x32 system : C:\Program Files\Webex\Webex\500
x64 system : C:\Program Files (x86)\Webex\Webex\500

----------------------------------------------------------------------------------------------------------------------------------------------

plugin download :

https://www.cisco.com/c/dam/en/us/td/docs/collaboration/webex_centers/Collaboration-Help/TS-Help-Portal-Support-Utilities/plugin.zip

-----------------------------------------------------------------------------------------------------------------------------------------