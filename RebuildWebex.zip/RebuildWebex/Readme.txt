*********************************************************************************************************************

How to use Rebuild Webex :

In order to use this program, you first need to get the folder with the WebEx session data.


The steps to use it are:

1. Play the WebEx recording from the meeting website.

2.	It should run the WeBex player. Pause the video and wait until the bottom bar is completely loaded (all blue).

3.	Without close the player, locate the folder with the session data. 

Order by date and it should show up as a folder whose name has several numbers.

- In Windows, the path is %temp%
- In Linux, the path is /home/[user_name]/.webex/500/[XXXXXXXX]
- In MacOS, the path is /Users/[user_name]/Library/Application\ Support/WebEx\ Folder/64_500/[XXXXXXXX]

4.	Copy the number folder to a new location.

5.	Open the program and load the folder copied before.

7.	The video should be created as rebuild.arf inside the number folder.

8.	The video can be played with the WebEx ARF Player

*********************************************************************************************************************